package textcodex;

import controller.NursesCntl;

public class Main {

    public static void main(String[] args) {
        TestHarness th = new TestHarness();
        NursesCntl nursesCntl = new NursesCntl();

    }
}
