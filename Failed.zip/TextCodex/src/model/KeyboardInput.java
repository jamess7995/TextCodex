package model;

public class KeyboardInput {
    private String keyboardInput;

/*    public Abbreviations(String userShortVersion) {
        this.userShortVersion = userShortVersion;
    }

    public Abbreviations() {
        this.userShortVersion = "";
    }
    public String getUserShortVersion() {
        return userShortVersion;
    }
    public void setuserShortVersion(String userShortVersion) {
        this.userShortVersion = userShortVersion;
    }

    @Override
    public String toString() {
        return userShortVersion + "\"";
    }*/
}
