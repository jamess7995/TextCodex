package controller;

import model.Model;
import view.View;

public class Controller {

    Model model;
    View view;

    public Controller(Model m)
    {
        model = m;
    }

/*    public Controller(View v, Model m)
    {
        model = m;
        view = v;
    }*/

}
