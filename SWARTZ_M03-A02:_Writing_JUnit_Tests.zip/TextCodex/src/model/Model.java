package model;

public class Model
{

    private Abbreviations userSV;

    private Expansions userLV;

/*    private Forms userShortVersion;

    private KeyboardInput userShortVersions;*/

    private Titles userST;
}
