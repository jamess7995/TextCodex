package model;

public class Forms {
    private String userForms;

/*    public Abbreviations(String userShortVersion) {
        this.userShortVersion = userShortVersion;
    }

    public Abbreviations() {
        this.userShortVersion = "";
    }
    public String getUserShortVersion() {
        return userShortVersion;
    }
    public void setuserShortVersion(String userShortVersion) {
        this.userShortVersion = userShortVersion;
    }

    @Override
    public String toString() {
        return userShortVersion + "\"";
    }*/
}
