package view;

import model.Abbreviations;

public class View {
    public View()
    {

    }
}
